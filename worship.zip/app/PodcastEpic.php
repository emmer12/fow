<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PodcastEpic extends Model
{
    //
}
