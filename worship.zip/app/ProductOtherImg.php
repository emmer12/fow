<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductOtherImg extends Model
{
    protected $fillable = ['product_id','other_img'];
}
