<div class="custum-msg-success">
  success
</div>
<div class="custum-msg-danger">
   danger
</div>
<div class="custum-msg-info">
  info
</div>
