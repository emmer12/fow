<div class="over">
  <h1>overlay</h1>
</div>
<div class="log-form">
   <span class="pull-right reg-close ti ti-close"></span>
   <ul class="list-inline text-center">
     <li class="active login">Login</li>
     <li class="signup">Sign up</li>
   </ul>


   <div class="signup-form">
     <div class="login-form-haed">
       <h4>WORSHIP LIFTING</h4>
       <p>SIGN UP</p>
     </div>
     <form>
       
     </form>
   </div>


</div>
