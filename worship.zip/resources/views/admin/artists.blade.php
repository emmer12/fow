@extends('layouts.app')

@section('content')
  <br>
<div class="container">
   <div class="">
     <h2>All Registerd Artist</h2>
   </div>
</div>
@endsection
