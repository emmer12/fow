@extends('layouts.app')

@section("content")
  @include('inc/drawer')
  <br>
   <div class="container">
     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-9">
         <div class="panel panel-default video-form">
           <div class="panel-heading" id="p-heading">
             <h4><strong>Post Audio<strong></h4>
           </div>
           <div class="panel-body">
             @if (session('success'))
               <div class="alert alert-success" role="alert">
                {{ session('success')}}
               </div>
             @endif
             @if (count($errors) > 0)
               @foreach ($errors->all() as $error)
                 <div class="alert alert-danger" role="alert">
                   {{ $error }}
                 </div>
               @endforeach
             @endif
             <form method="POST" action="{{ route('admin-storeAudio')}}" enctype="multipart/form-data">
               {{ csrf_field() }}
               <fieldset class="form-group">
                 <label for="title">Audio Title</label>
                 <input value="{{ old('title') }}" type="text" name="title" class="form-control" id="title" placeholder="Audio Title ">
               </fieldset>
               <fieldset class="form-group">
                 <label for="discription">Audio Discription</label>
                 <textarea value="{{ old('discription') }}" name="discription" class="form-control" rows="3" cols="50"></textarea>
               </fieldset>
               <fieldset class="form-group">
                 <label for="lyrics">Lyrics</label>
                 <textarea value="{{ old('lyrics') }}" name="lyrics" class="form-control" rows="6" cols="60"></textarea>
               </fieldset>
               <fieldset class="form-group">
                 <label for="artist_name">Airtist Name</label>
                 <input value="{{ old('artist_name') }}" type="text" name="artist_name" class="form-control" id="artist_name" placeholder="Video Title ">
               </fieldset>
               <fieldset class="form-group">
                 <select class="form-control" name="author_id">
                   <option value="">Choose Registered Artist</option>
                   @foreach ($worshipers as $worshiper)
                     <option value="{{ $worshiper->id }}">{{ $worshiper->name }}</option>
                   @endforeach
                 </select>
               </fieldset>
               <fieldset class="form-group">
                 <label for="p-image">Preview Image</label>
                 <div class="row">
                    <div class="col-lg-4">
                      <input value="{{ old('preview_image') }}" type="file" name="preview_image" class="dropify preview_image" id="p-image" >
                    </div>
                  </div>
               </fieldset>
               <fieldset class="form-group">
                 <label for="video">Audio</label>
                 <div class="row">
                    <div class="col-lg-4">
                      <input value="{{ old('audio') }}" type="file" name="audio" id="audio" class="dropify video" >
                    </div>
                  </div>
               </fieldset>
               <button type="submit" class="btn btn-primary">POST</button>
             </form>
           </div>
         </div>

       </div>
     </div>
   </div>
@endsection("content")
