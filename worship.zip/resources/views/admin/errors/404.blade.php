@extends('layouts.app')
@section("content")
  <div class="container">
    <div class="jumbotron">
      <h1 class="display-3">404</h1>
      <p class="lead">Page not found</p>
    </div>
  </div>
@endsection("content")
