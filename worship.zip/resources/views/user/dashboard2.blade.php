@extends("layouts.app")
{{-- elevation worship backgreund:#eeeeef --}}
@section("content")
   <div class="">
     <h2>Admin dashboard</h2>
   </div>
@endsection("content")
