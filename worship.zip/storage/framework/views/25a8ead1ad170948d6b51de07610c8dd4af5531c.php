<?php $__env->startSection("content"); ?>
  <?php echo $__env->make('inc/drawer-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <br>
   <div class="container">
     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-9">
         <div class="pull-right">
           <button type="button" class="btn btn-default"><a href="#">Total Post<span class="label label-pill label-success"><?php echo e(count($audios)); ?></span> </a></button>
           <?php if(@isset($create) || @isset($edit) ): ?>
             <button type="button" class="btn btn-default"><a href="<?php echo e(route("admin.dashboard.audio")); ?>">Back</a></button>
             <?php else: ?>
             <button type="button" class="btn btn-success"><a href="<?php echo e(route("audio.action",['action'=>"create","id"=>'add'])); ?>">Add</a></button>
           <?php endif; ?>
         </div>
         <hr>

         <?php if(@isset($create)): ?>
           <div class="panel panel-default video-form">
             <div class="panel-heading" id="p-headg">
               <span class="glyphicon glyphicon-plus"></span> Create Audio
             </div>
             <div class="panel-body">
                 <form method="POST" action="<?php echo e(route('admin-storeAudio')); ?>" enctype="multipart/form-data">
                   <?php echo e(csrf_field()); ?>

                   <fieldset class="form-group">
                     <label for="title">Audio Title</label>
                     <input value="<?php echo e(old('title')); ?>" type="text" name="title" class="form-control" id="title" placeholder="Audio Title ">
                   </fieldset>
                   <fieldset class="form-group">
                     <label for="discription">Audio Discription</label>
                     <textarea value="<?php echo e(old('discription')); ?>" name="discription" class="form-control" rows="3" cols="50"></textarea>
                   </fieldset>
                   <fieldset class="form-group">
                     <label for="lyrics">Lyrics</label>
                     <textarea value="<?php echo e(old('lyrics')); ?>" name="lyrics" class="form-control" rows="6" cols="60"></textarea>
                   </fieldset>
                   <fieldset class="form-group">
                     <label for="artist_name">Airtist Name</label>
                     <input value="<?php echo e(old('artist_name')); ?>" type="text" name="artist_name" class="form-control" id="artist_name" placeholder="Video Title ">
                   </fieldset>
                   <fieldset class="form-group">
                     <label for="p-image">Preview Image</label>
                     <div class="row">
                        <div class="col-lg-4">
                          <input value="<?php echo e(old('preview_image')); ?>" type="file" name="preview_image" class="dropify preview_image" id="p-image" >
                        </div>
                      </div>
                   </fieldset>
                   <fieldset class="form-group">
                     <label for="video">Audio</label>
                     <div class="row">
                        <div class="col-lg-4">
                          <input value="<?php echo e(old('audio')); ?>" type="file" name="audio" id="audio" class="dropify video" >
                        </div>
                      </div>
                   </fieldset>
                   <button type="submit" class="btn btn-primary">POST</button>
                 </form>
               </div>
             </div>
           <?php elseif(@isset($edit)): ?>
             <div class="panel panel-default">
               <div class="panel-heading" id="">
                <span class="glyphicon glyphicon-pencil"></span>Edit Audio
               </div>
               <div class="panel-body">
                 <?php if(count($errors)>0): ?>
                   <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="alert alert-danger" role="alert">
                       <?php echo e($error); ?>

                     </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php endif; ?>
                     <form method="POST" action="<?php echo e(route('audio.update',$audio->id)); ?>" enctype="multipart/form-data">
                       <?php echo e(csrf_field()); ?>

                       <?php echo e(method_field("PATCH")); ?>

                       <fieldset class="form-group">
                         <label for="title">Audio Title</label>
                         <input value="<?php echo e($audio->title); ?>" type="text" name="title" class="form-control" id="title" placeholder="Audio Title ">
                       </fieldset>
                       <fieldset class="form-group">
                         <label for="discription">Audio Discription</label>
                         <textarea value="<?php echo e(old('discription')); ?>" name="discription" class="form-control" rows="3" cols="50"><?php echo e($audio->discription); ?></textarea>
                       </fieldset>
                       <fieldset class="form-group">
                         <label for="lyrics">Lyrics</label>
                         <textarea value="<?php echo e(old('lyrics')); ?>" name="lyrics" class="form-control" rows="6" cols="60"><?php echo e($audio->lyric); ?></textarea>
                       </fieldset>
                       <fieldset class="form-group">
                         <label for="artist_name">Airtist Name</label>
                         <input value="<?php echo e($audio->artist_name); ?>" type="text" name="artist_name" class="form-control" id="artist_name" placeholder="Video Title ">
                       </fieldset>
                       <fieldset class="form-group">
                         <label for="p-image">Preview Image</label>
                         <div class="row">
                            <div class="col-lg-4">
                              <input value="<?php echo e(old('preview_image')); ?>" type="file" name="preview_image" class="dropify preview_image" id="p-image" >
                            </div>
                          </div>
                       </fieldset>
                       <fieldset class="form-group">
                         <label for="video">Audio</label>
                         <div class="row">
                            <div class="col-lg-4">
                              <input value="<?php echo e(old('audio')); ?>" type="file" name="audio" id="audio" class="dropify video" >
                            </div>
                          </div>
                       </fieldset>
                       <button type="submit" class="btn btn-primary">Update</button>
                     </form>
                  </div>
                </div>

             <?php else: ?>
                 <div class="div product">
                   <div class="panel panel-default">
                     <div class="panel-heading">
                      <span class="glyphicon glyphicon-list"></span>  Audio Listing
                     </div>
                     <div class="panel-body">
                       <?php if(session('success')): ?>
                         <div class="alert alert-success" role="alert">
                          <?php echo e(session('success')); ?>

                         </div>
                       <?php endif; ?>
                       <?php if(count($errors) > 0): ?>
                         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="alert alert-danger" role="alert">
                             <?php echo e($error); ?>

                           </div>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                       <?php endif; ?>
                         <div class="table-responsive">
                           <table class="table table-bordered table-hover">
                             <thead>
                               <tr>
                                 <th class="text-center">images</th>
                                 <th>Title</th>
                                 <th class="text-center">Audio</th>
                                 <th class="text-center">Artist</th>
                                 <th class="text-center">Status</th>
                                 <th class="text-center">Action</th>
                               </tr>
                             </thead>
                             <tbody>

                                <?php $__currentLoopData = $audios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr class="parent<?php echo e($audio->id); ?>">
                                    <td class="text-center"><img class="" src="/storage/uploads/images/<?php echo e($audio->preview_image); ?>" width="100px" height="70px" alt="<?php echo e($audio->product_title); ?>"></td>
                                    <td><?php echo e($audio->title); ?></td>
                                    <td> <audio src="/storage/uploads/audios/<?php echo e($audio->music); ?>" controls></audio> </td>
                                    <td class="text-center"><?php echo e($audio->artist_name); ?></td>
                                    <td class="text-center">
                                      <?php if($audio->status): ?>
                                        <button type='button' class="btn btn-danger permit" data-id='<?php echo e($audio->id); ?>' action='Disapprove' data-item='audio'>Disapprove</button>
                                         <?php else: ?>
                                        <button type='button' class="btn btn-success permit" data-id='<?php echo e($audio->id); ?>' action='Approve' data-item='audio'>Approve</button>
                                      <?php endif; ?>
                                    </td>
                                    <td width="15%" class="text-center"><a class="btn btn-primary edit" href="<?php echo e(route("audio.action",['edit',$audio->id])); ?>"><span class="ti ti-pencil"></span> </a> | <a  href="#" data-id="<?php echo e($audio->id); ?>" class="btn btn-danger edit delete" data-item="audio"><span class="ti ti-trash"></span> </a></td>
                                  </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </tbody>
                           </table>
                         </div>
                     </div>
                   </div>
                 </div>
      <?php endif; ?>
       </div>
     </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>