<div>
    Hi, This is : <?php echo e($name); ?>

</div>
