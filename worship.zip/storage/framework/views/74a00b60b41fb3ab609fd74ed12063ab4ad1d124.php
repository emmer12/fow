<?php $__env->startSection("content"); ?>
  <br>
   <div class="container">
     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-5">
         <div class="panel panel-default video-form">
           <div class="panel-heading">
             <h4 class="heading">Contribution</h4>
             <?php if(session('msg')): ?>
               <div class="alert alert-success" role="alert">
                 <span class="ti ti-control-play"></span>
                 <?php echo e(session('msg')); ?>

               </div>
             <?php endif; ?>
           </div>
           <div class="panel-body">
             <?php if(count($errors) > 0): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="alert alert-danger" role="alert">
                   <?php echo e($error); ?>

                 </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             <?php endif; ?>
             <div class="">
               <div class="well">
                 <div class="alert alert-default" role="alert">
                   <i class="fa fa-share-square" aria-hidden></i>
                   <h4>Click bellow to send a request to contribute to our blog post</h4>
                 </div>
                 <form method="POST" action="<?php echo e(route('author.request')); ?>" enctype="multipart/form-data">
                   <?php echo e(csrf_field()); ?>

                   <input type="hidden" name="type" value="author_request">
                   <button type="submit" class="btn btn-primary">Send Request <span class="ti ti-share"></span> </button>
                 </form>
               </div>
               </div>
             </div>
             
         </div>

       </div>
     </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>