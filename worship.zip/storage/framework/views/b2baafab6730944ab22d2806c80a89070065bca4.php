<style media="screen">
.m-banner-single{
 background: rgba(0,0,0, 0.5);
 width: 100%;
 padding:10px;
 top: 0px;
 color: white;
 filter: none;
 position: relative;
 margin-top:-200px;
}
.m-banner-single video{
height: 300px;
}
.m-banner-single span{
  cursor: pointer;
  padding: 10px;

}
.m-banner-single a{
  position:absolute;
  z-index:20;
  font-size:25px;
  color: white;
  font-weight: 700;
  left: -5px;
  top: -80px;
}
.m-banner-single .vid-details{
  background: white;
  color: #636b6f;
  padding: 10px;
}
.video-action span{
  cursor: pointer;
}
.video-action span:nth-child(3){
  color: white;
  background: #4a6ea9;
}
.video-action span:nth-child(2){
  color: white;
  background:#32ddf3;
}
</style>



<?php $__env->startSection("content"); ?>
  <?php if($audio_post->count()<1): ?>
    <div class="alert alert-warning" role="alert">
      No Vidio with this name available
    </div>
    <a href="<?php echo e(route('home-page')); ?>"><button type="button" class="btn btn-primary"> <span class="ti ti-arrow-left"></span> Go back To Home </button></a>
    <?php else: ?>
      <div class="">
        <div class="vid-single-banner text-center">
        </div>
        <div class="container">
          <div class="m-banner-single">
            
            <a href="<?php echo e(route('team-page')); ?>">
              <span class="ti ti-arrow-left"></span>
            </a>
            <audio  src="/storage/uploads/audios/<?php echo e($audio_post->music); ?> " class="center-block"  width="100%" height="230px" controls poster="/storage/uploads/images/<?php echo e($audio_post->preview_image); ?> " class="vid"></audio>
            <div class="vid-details">
              <h4><?php echo e($audio_post->title); ?> by <strong></strong></h4>
              <div class="panel panel-default">
                <div class="panel-heading">
                  Discription <span class="opener ti ti-angle-down pull-right"></span>
                </div>
                <div class="panel-body mobile-sub-menu">
                  <p><?php echo e($audio_post->discription); ?></p>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading">
                  Lyrics <span class="opener ti ti-angle-down pull-right"></span>
                </div>
                <div class="panel-body mobile-sub-menu">
                  <p>
                    <?php if(strlen($audio_post->lyric)==0): ?>
                      Lyric is not available
                    <?php else: ?>
                      <?php echo e($audio_post->lyric); ?>

                    <?php endif; ?>
                  </p>
                </div>
              </div>
              <div class="video-action">
                <button type="button" class="btn btn-success">DOWNLOAD <span class="ti ti-download"></span> </button>
                <span class="ti ti-twitter pull-right"></span><span class="ti ti-facebook pull-right"></span>
              </div>
            </div>
          </div>
        </div>

  <?php endif; ?>
  <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>