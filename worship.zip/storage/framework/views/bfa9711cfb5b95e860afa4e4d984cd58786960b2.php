<style media="screen">

</style>
<?php $__env->startSection("content"); ?>
  <?php echo $__env->make('inc/drawer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <br>
   <div class="container">
     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-9">
         <div class="panel panel-default video-form">
           <div class="panel-heading" id="p-heading">
             <h4><strong>Volunteers</strong></h4>
           </div>
           <div class="panel-body">
             <?php if(session('success')): ?>
               <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

               </div>
             <?php endif; ?>
             <?php if(count($errors) > 0): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="alert alert-danger" role="alert">
                   <?php echo e($error); ?>

                 </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             <?php endif; ?>
            <div class="">
              <?php if(count($volunteers) < 1): ?>
                <div class="alert alert-info" role="alert">
                  No Voluntered Users
                </div>
               <?php else: ?>
                 <h5><?php echo e(count($volunteers)); ?> has Voluntered</h5>

                 <ul class="list-group">
                <?php $__currentLoopData = $volunteers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $volunteer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item" style="margin:5px"><?php echo e($volunteer->firstname); ?> <span style="background:#ddd;padding:10px;border-radius:100%" class="opener-multi ti ti-angle-down pull-right" data-id="<?php echo e($volunteer->id); ?>"></span> </li>
                    <div class="mobile-sub-menu mobile-sub-menu<?php echo e($volunteer->id); ?>">
                      <div class="text-center">
                        <img src="/images/testimonial.jpg"   alt="">
                        <hr>
                        <strong>Firstname::</strong><?php echo e($volunteer->firstname); ?><br>
                        <strong>Lastname::</strong><?php echo e($volunteer->lastname); ?><br>
                        <strong>Email Address::</strong> <a href="mail:<?php echo e($volunteer->email); ?>"><?php echo e($volunteer->email); ?></a><br>
                        <strong>Phone Number::</strong> <a href="tel:<?php echo e($volunteer->phoneNo); ?>"><?php echo e($volunteer->phoneNo); ?></a> <br>
                        <strong>Interested Role::</strong><?php echo e($volunteer->role); ?><br>
                        <strong> Gender::</strong><?php echo e($volunteer->gender); ?><br>
                      </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              <?php endif; ?>
            </div>
           </div>
         </div>

       </div>
     </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>