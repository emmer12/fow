<style media="screen">

</style>
<?php $__env->startSection("content"); ?>
  <?php echo $__env->make('inc/drawer-customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <br>
   <div class="container">
     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-9">
          <div class="jumbotron">
            <h2 class="display-1 wow fadeInUp">You are welcome <?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->lastname); ?> </h2>
            <p class="lead">.</p>
            <hr class="m-y-md">
            <p class="lead wow fadeInUp">
              <a class="btn btn-primary btn-lg" href="<?php echo e(route('order.display')); ?>" role="button">View Orders</a>
            </p>
          </div>
       </div>
     </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>