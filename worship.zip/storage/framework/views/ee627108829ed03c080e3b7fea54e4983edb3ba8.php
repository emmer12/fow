<?php $__env->startSection("content"); ?>
  <br>
   <div class="">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="img-display">
            <img src="/storage/uploads/images/<?php echo e($book->preview_image); ?>" width="100%" height="90%" class="product-img center-block" alt="">
            <div class="action">
              <?php if($book->price): ?>
                <button type="submit" class="btn btn-success btn-lg center-block" id="desk-show">Buy</span> </button>
                <?php else: ?>
                <a href="/storage/uploads/books/<?php echo e($book->file); ?>" class="btn btn-success btn-lg center-block desk-show" ><span class="ti ti-download"></span> </a>
              <?php endif; ?>
              </form>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="product-s-details">
            <h4 class="title"><?php echo e($book->title); ?></h4>
            as low as <span> <b>&#x20A6;<?php echo e($book->price); ?></b> </span>
            <hr>
            <h4><b>Category</b></h4>
            <a href="<?php echo e(route("store-category-page",str_slug($book->category,'-'))); ?>"><?php echo e($book->category); ?></a>
            <h4> <b>Description</b> </h4>
            <p><?php echo e($book->description); ?></p>
            <hr>
            <ul class="list-inline">
              <li> <span class="ti ti-facebook"> Share</span> </li>
              <li> <span class="ti ti-twitter"> Tweet</span> </li>
              <li></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
      <br>
    </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>