<?php $__env->startSection("content"); ?>
   <div class="container">
     <div class="blog-nav">
       <ul class="nav nav-tabs">
         <li class="nav-item">
           <a href="<?php echo e(route("blog.index")); ?>" class="nav-link active-ms">All</a>
         </li>
         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <li class="nav-item">
             <a href="<?php echo e(route("blog.category",$category->name)); ?>" class="nav-link"><?php echo e($category->name); ?></a>
           </li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </ul>
     </div>
     <h4 class="heading">Latest News</h4>
     <div class="row">
       <?php if(count($blogPostTag) > 0): ?>
         <?php $__currentLoopData = $blogPostTag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-md-4 " >
             <div class="card blog-design" style="margin-left:3px;">
               <?php if($blogPost->preview_image=="default.jpg"): ?>

                 <?php else: ?>
                   <a href="<?php echo e(route('blog.show',$blogPost->slug)); ?>">
                     <img class="card-img top" src="/storage/uploads/images/<?php echo e($blogPost->preview_image); ?>" width="100%" height="250px" alt="Card image cap">
                   </a>
               <?php endif; ?>
               <div class="card-block">
                 <a href="<?php echo e(route('blog.show',$blogPost->slug)); ?>">
                   <h4 class="card-title"><?php echo e($blogPost->title); ?></h4>
                 </a>
                 <div class="blog-info-div">
                   <p class="card-text"><?php echo e($blogPost->body); ?></p>
                   <span><i class="ti ti-time"> <?php echo e($blogPost->created_at); ?></i></span>
                   <span class="pull-right"><a href="<?php echo e(route('blog.show',$blogPost->slug)); ?>">read more..</a> </span>
                 </div>

               </div>
             </div>
           </div>
           
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php else: ?>
           <div class="alert alert-info" role="alert">
             No Post Under this category
           </div>
       <?php endif; ?>



     </div>
     <nav>
       <ul class="pager">
         <?php echo e($blogPostTag->links()); ?>

       </ul>
     </nav>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>