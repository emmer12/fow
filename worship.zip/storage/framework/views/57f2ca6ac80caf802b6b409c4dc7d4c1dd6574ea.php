<style media="screen">
  .span{
    position: absolute;
    background: #222;
    padding:5px 10px;
    margin-top:3px;
    border-radius: 10px;
    color: white;
    //display: none;
    right: 0px
  }
  .span::before{
    content: '';
    position: absolute;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 10px solid #222;
    transform: rotate(130deg);
    top: -4px;
    left: -3px;
  }
</style>

<?php $__env->startSection("content"); ?>
  <?php echo $__env->make('inc/drawer-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <br>
   <div class="container">
     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-9">
         <div class="pull-right">
           <button type="button" class="btn btn-default"><a href="#">Total Post <span class="label label-pill label-success"><?php echo e(count($blogposts)); ?></span> </a></button>
           <?php if(@isset($create) || @isset($edit) ): ?>
             <button type="button" class="btn btn-default"><a href="<?php echo e(route("admin.dashboard.blog")); ?>">Back</a></button>
             <?php else: ?>
             <button type="button" class="btn btn-success"><a href="<?php echo e(route("blog.action",['action'=>'create','id'=>'add'])); ?>">Add</a></button>
           <?php endif; ?>
         </div>
         <hr>

        <?php if(@isset($create)): ?>
           <div class="panel panel-default">
             <div class="panel-heading">
              <span class="glyphicon glyphicon-shopping-cart"></span> Create Product
             </div>
             <div class="panel-body">
               <?php if(session('success')): ?>
                 <div class="alert alert-success" role="alert">
                  <?php echo e(session('success')); ?>

                 </div>
               <?php endif; ?>
               <?php if(count($errors) > 0): ?>
                 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="alert alert-danger" role="alert">
                     <?php echo e($error); ?>

                   </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               <?php endif; ?>

               <form method="POST" action="<?php echo e(route('create.blog')); ?>" enctype="multipart/form-data">
                 <?php echo e(csrf_field()); ?>

                 <fieldset class="form-group">
                   <label for="title">Post Title Or Testimoneer Name</label>
                   <input value="<?php echo e(old('title')); ?>" type="text" name="title" class="form-control" id="title" placeholder="Title or testimoneer name">
                   <span class="span">Please enter blog post title or testifier's name </span>
                 </fieldset>

                 <fieldset class="form-group">
                   <label for="body">Body</label>
                   <textarea value="<?php echo e(old('body')); ?>" id="body" name="body" class="form-control" rows="3" cols="50"></textarea>
                 </fieldset>
                 <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
                 <fieldset class="form-group">
                   <select class="form-control" name="category">
                       <option value="">Select Category</option>
                       <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
                 </fieldset>
                 <fieldset>
                      <div class="">
                        <input value="<?php echo e(old('tags')); ?>" placeholder='write some tags seperate with comma' type="text" name="tags" class="orm-control" id="tags" >
                      </div>
                 </fieldset>
                 <fieldset class="form-group">
                   <label for="p-image">Preview Image</label>
                   <div class="row">
                      <div class="col-lg-4">
                        <input value="<?php echo e(old('preview_image')); ?>" type="file" name="preview_image" class="dropify preview_image" id="p-image" >
                      </div>
                    </div>
                 </fieldset>
                 <button type="submit" class="btn btn-primary">POST</button>
               </form>
             </div>
           </div>
          <?php elseif(@isset($edit)): ?>
            <div class="panel panel-default">
              <div class="panel-heading">
               <span class="glyphicon glyphicon-list"></span> Editing
              </div>
              <div class="panel-body">
                <?php if(session('success')): ?>
                  <div class="alert alert-success" role="alert">
                   <?php echo e(session('success')); ?>

                  </div>
                <?php endif; ?>
                <?php if(count($errors) > 0): ?>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($error); ?>

                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>

               <form method="POST" action="<?php echo e(route('storeBlog.update',$blog->id)); ?>" enctype="multipart/form-data">
                 <?php echo e(csrf_field()); ?>

                 <?php echo e(method_field('PATCH')); ?>

                 <fieldset class="form-group">
                   <label for="title">Post Title Or Testimoneer Name</label>
                   <input value="<?php echo e($blog->title); ?>" type="text" name="title" class="form-control" id="title" placeholder="Title or testimoneer name">
                   <span class="span">Please enter blog post title or testifier's name </span>
                 </fieldset>

                 <fieldset class="form-group">
                   <label for="body">Body</label>
                   <textarea value="<?php echo e($blog->body); ?>" id="body" name="body" class="form-control" rows="3" cols="50"><?php echo e($blog->body); ?></textarea>
                 </fieldset>
                 <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
                 <fieldset class="form-group">
                   <select class="form-control" name="category">
                       <option value="<?php echo e($blog->category); ?>"><?php echo e($blog->category); ?></option>
                       <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value="<?php echo e($category->name); ?>"><?php echo e($category->name); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
                 </fieldset>
                 <fieldset>
                      <div class="">
                        <input value="<?php echo e($blog->tags); ?>" placeholder='write some tags seperate with comma' type="text" name="tags" class="orm-control" id="tags" >
                      </div>
                 </fieldset>
                 <fieldset class="form-group">
                   <label for="p-image">Preview Image</label>
                   <div class="row">
                      <div class="col-lg-4">
                        <input value="<?php echo e(old('preview_image')); ?>" type="file" name="preview_image" class="dropify preview_image" id="p-image" >
                      </div>
                    </div>
                 </fieldset>
                 <button type="submit" class="btn btn-primary">Update</button>
               </form>
              </div>
            </div>
          <?php else: ?>
            <div class="div product">
              <div class="panel panel-default">
                <div class="panel-heading">
                 <span class="glyphicon glyphicon-list"></span>  Blog listing
                </div>
                <div class="panel-body">
                  <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                     <?php echo e(session('success')); ?>

                    </div>
                  <?php endif; ?>
                  <?php if(count($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="alert alert-danger" role="alert">
                        <?php echo e($error); ?>

                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  <?php endif; ?>
                    <div class="table-responsive">
                      <table class="table table-bordered table-hover">
                        <thead>
                          <tr>
                            <th class="text-center">images</th>
                            <th>Blog Title</th>
                            <th class="text-right">Tags</th>
                            <th class="text-right">Author</th>
                            <th>Status</th>
                            <th colspan="2" class="text-right">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                           <?php $__currentLoopData = $blogposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr class="parent<?php echo e($blogpost->id); ?>">
                               <td class="text-center"><img class="" src="/storage/uploads/images/<?php echo e($blogpost->preview_image); ?>" width="100px" height="70px" alt="<?php echo e($blogpost->product_title); ?>"></td>
                               <td><?php echo e($blogpost->title); ?></td>
                               <td class="text-right"><?php echo e($blogpost->tags); ?></td>
                               <td class="text-right"><?php echo e($blogpost->qty); ?></td>
                               <td>
                                 <?php if($blogpost->status): ?>
                                   <button type='button' class="btn btn-danger permit" data-id='<?php echo e($blogpost->id); ?>' action='Disapprove' data-item='blog'>Disapprove</button>
                                    <?php else: ?>
                                   <button type='button' class="btn btn-success permit" data-id='<?php echo e($blogpost->id); ?>' action='Approve' data-item='blog'>Approve</button>
                                 <?php endif; ?>
                               </td>
                               <td width="15%" class="text-center"><a class="btn btn-primary edit" href="<?php echo e(route("blog.action",['action'=>'edit','id'=>$blogpost->id])); ?>"><span class="ti ti-pencil"></span> </a> | <a  href="#" data-id="<?php echo e($blogpost->id); ?>" class="btn btn-danger edit delete" data-item="blog"><span class="ti ti-trash"></span> </a> </td>
                             </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                          <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td colspan=6>
                              <ul class="pager">
                                <?php echo e($blogposts->links()); ?>

                              </ul>
                         </td>
                        </tr>
                        </tfoot>
                      </table>
                    </div>
                </div>
              </div>
        <?php endif; ?>


           </div>
         </div>


       </div>
     </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>