<div class="over">
  <h1>overlay</h1>
</div>
<div class="log-form">
   <span class="pull-right reg-close ti ti-close"></span>
   <ul class="list-inline text-center">
     <li class="active login">Login</li>
     <li class="signup">Sign up</li>
   </ul>
   

   <div class="signup-form">
     <div class="login-form-haed">
       <h4>WORSHIP LIFTING</h4>
       <p>SIGN UP</p>
     </div>
     <form>
       <fieldset class="form-group">
         <label for="firstname">Firstname</label>
         <input type="type" class="form-control" id="firstname" placeholder="Firstname">
       </fieldset>
       <fieldset class="form-group">
         <label for="lasstname">Lastname</label>
         <input type="type" class="form-control" id="lasstname" placeholder="Lastname">
       </fieldset>
       <fieldset class="form-group">
         <label for="phoneNo">Phonen Number</label>
         <input type="number" class="form-control" id="phoneNo" placeholder="Phone Number">
       </fieldset>
       <fieldset class="form-group">
         <label for="email">Email</label>
         <input type="email" class="form-control" id="email" placeholder="example@mail.com">
       </fieldset>
       <fieldset class="form-group">
         <label for="password">Password</label>
         <input type="password" class="form-control" id="password" placeholder="******">
       </fieldset>
       <fieldset class="form-group">
         <label for="confirm-p">Confirm Password</label>
         <input type="password" class="form-control" id="confirm-p" placeholder="******">
       </fieldset>
       <button type="submit" class="btn btn-primary center-block">LOGIN</button><br>
        <a href="#"><i class="pull-right"><b>Already have an account ?</b></i></a>
     </form>
   </div>


</div>
