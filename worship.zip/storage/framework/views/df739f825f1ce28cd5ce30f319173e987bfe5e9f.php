   
<?php $__env->startSection("content"); ?>
  <div class="overlay">

  </div>
   <div class="">
     <div class="v-banner text-center">
       <div class="m-banner-c">
         <span class="glyphicon glyphicon-camera "></span>
         <h4>Video</h4>
       </div>
     </div>
   </div>
   <br>
     <div class="container">
       <div class="row">
         <?php if($video_posts->count() < 1): ?>
           <div class="alert alert-warning" role="alert">
             No Video is avalable
           </div><br>
           <a href="<?php echo e(route('home-page')); ?>"><button type="button" class="btn btn-primary"> <span class="ti ti-arrow-left"></span> Go back To Home </button></a>
           <?php else: ?>
             

             <?php $__currentLoopData = $video_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               <div class="col-md-6">
                 <div class="v-div">
                   <a class="" href="<?php echo e(route("video-show","$video_post->slug")); ?>" style="color:inherit">
                     <img src="/storage/uploads/images/<?php echo e($video_post->preview_image); ?>" alt="">
                   </a>
                   <a href="<?php echo e(route("video-show","$video_post->slug")); ?>" style="color:inherit">
                     <span style="padding:10px">Title Of Video</span>
                   </a>
                   <div class="play-time pull-right">
                     <span class="ti ti-control-play video-p" data-id="vid-1"></span>
                     <span>5:00</span>
                   </div>
                 </div>
                 <div class="vid-display-con vid-display-con-vid-1">
                   <video src="/storage/uploads/videos/<?php echo e($video_post->video); ?>" class="video-vid-1" loop style="position:absolute;width:100%;height:340px" poster="posterimage.jpg"></video>
                   <div class="control">
                     <h4>Tilte</h4>
                     <div class="dis-play-time pull-right">
                       <span class="ti ti-control-play video-p" data-id='vid-1'></span>
                       <span>5:00</span>
                       <span class="ti ti-close close-vid" ></span>
                     </div>
                   </div>
                 </div>
               </div>

             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


             



         <?php endif; ?>



       </div>
     </div>
   <nav>
     <ul class="pager-custom">
       <?php echo e($video_posts->links()); ?>

     </ul>
   </nav>
   <ol class="breadcrumb" style="margin-bottom: 5px;">
     <li><a href="/">Home</a></li>
     <li class="active">Music</li>
   </ol>
   <script type="text/javascript" src="/js/plugins/jquery.prettyPhoto.js"></script>
   <h2>Picture alone</h2>
   <ul class="gallery clearfix">
     <li><a href="images/cover.jpg?width=495&amp;height=275&amp;" rel="prettyPhoto" title="&lt;a href=&#x27;http://www.google.ca&#x27; target=&#x27;_blank&#x27; &gt;This will open Google.com in a new window&lt;/a&gt;"><img src="images/cover.jpg" width="60" height="60" alt="Picture alone 1" /></a></li>
   </ul>

   <script type="text/javascript">
   // $(document).ready(function () {
   //   function time(vid,time){
   //     var getMin=Math.floor(vid.duration/60);
   //     var getSec=Math.floor(vid.duration-getMin*60);
   //     time.innerHTML=getMin+":"+getSec;
   //   }
   //   var time=$("video");
   //   if (time) {
   //
   //   }
   //   console.log(time[0].duration);
   //   for (var i = 0; i < time.length; i++) {
   //   }
   // })

   </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>