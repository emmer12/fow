<style media="screen">
   .list-post{
     cursor: pointer;
   }
</style>
<?php $__env->startSection("content"); ?>
  <?php echo $__env->make('inc/drawer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('inc/messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <br>
   <div class="container">
     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-9">
         <div class="panel panel-default video-form">
           <div class="panel-heading" id="p-heading">
             <h4> <strong>Video Management</strong></h4>
           </div>
           <div class="panel-body">
             <?php if(session('success')): ?>
               <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

               </div>
             <?php endif; ?>
             <?php if(count($errors) > 0): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="alert alert-danger" role="alert">
                   <?php echo e($error); ?>

                 </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             <?php endif; ?>
            <div class="">
              <?php if(count($videos) < 1): ?>
                <div class="alert alert-info" role="alert">
                  No Video Posts
                </div>
               <?php else: ?>
                 <h5><?php echo e(count($videos)); ?> Video post(s)</h5>

                 <ul class="list-group">
                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item list-post " style="margin:5px"><?php echo e($video->title); ?> <span style="background:#ddd;padding:10px;border-radius:100%" class="delete_post ti ti-close pull-right" data-table="VideoPost" data-id="<?php echo e($video->id); ?>" ></span> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              <?php endif; ?>
            </div>
           </div>
         </div>

       </div>
     </div>

     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-9">
         <div class="panel panel-default video-form">
           <div class="panel-heading">
             <h4>Audio Management</h4>
           </div>
           <div class="panel-body">
             <?php if(session('success')): ?>
               <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

               </div>
             <?php endif; ?>
             <?php if(count($errors) > 0): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="alert alert-danger" role="alert">
                   <?php echo e($error); ?>

                 </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             <?php endif; ?>
            <div class="">
              <?php if(count($audios) < 1): ?>
                <div class="alert alert-info" role="alert">
                  No Audio post(s)
                </div>
               <?php else: ?>
                 <h5><?php echo e(count($audios)); ?> Audio posts</h5>

                 <ul class="list-group">
                <?php $__currentLoopData = $audios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item list-post" style="margin:5px"><?php echo e($audio->title); ?> <span style="background:#ddd;padding:10px;border-radius:100%" class="delete_post ti ti-close pull-right" data-table="MusicPost" data-id="<?php echo e($audio->id); ?>"></span> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              <?php endif; ?>
            </div>
           </div>
         </div>

       </div>
     </div>

     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-9">
         <div class="panel panel-default video-form">
           <div class="panel-heading">
             <h4>Blog Management</h4>
           </div>
           <div class="panel-body">
             <?php if(session('success')): ?>
               <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

               </div>
             <?php endif; ?>
             <?php if(count($errors) > 0): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="alert alert-danger" role="alert">
                   <?php echo e($error); ?>

                 </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             <?php endif; ?>
            <div class="">
              <?php if(count($blogs) < 1): ?>
                <div class="alert alert-info" role="alert">
                  No Blog Post(s)
                </div>
               <?php else: ?>
                 <h5><?php echo e(count($blogs)); ?> Blog post(s)</h5>

                 <ul class="list-group">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item list-post" style="margin:5px"><?php echo e($blog->title); ?> <span style="background:#ddd;padding:10px;border-radius:100%" class="delete_post ti ti-close pull-right" data-table="BlogPosts" data-id="<?php echo e($blog->id); ?>"></span> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              <?php endif; ?>
            </div>
           </div>
         </div>

       </div>
     </div>

     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-9">
         <div class="panel panel-default video-form">
           <div class="panel-heading">
             <h4>Product Management</h4>
           </div>
           <div class="panel-body">
             <?php if(session('success')): ?>
               <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

               </div>
             <?php endif; ?>
             <?php if(count($errors) > 0): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="alert alert-danger" role="alert">
                   <?php echo e($error); ?>

                 </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             <?php endif; ?>
            <div class="">
              <?php if(count($products) < 1): ?>
                <div class="alert alert-info" role="alert">
                  No Product Post(s)
                </div>
               <?php else: ?>
                 <h5><?php echo e(count($products)); ?> Product Post(s)</h5>

                 <ul class="list-group">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item list-post" style="margin:5px"><?php echo e($product->product_title); ?> <span style="background:#ddd;padding:10px;border-radius:100%" class="delete_post ti ti-close pull-right" data-table="Product" data-id="<?php echo e($product->id); ?>"></span> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              <?php endif; ?>
            </div>
           </div>
         </div>

       </div>
     </div>

   </div>
   <script type="text/javascript">
       $(document).ready(function(){
         $('.delete_post').click(function() {
           var shouldDelete=confirm("Are Sure You Want To Delete this post");
           if (shouldDelete) {
             var currentElement=$(this);
             var table=$(this).attr('data-table');
             var id=$(this).attr('data-id');
             var urls="<?php echo e(route('post.destroy')); ?>";
             $.ajax({
               url:urls,
               method:'POST',
               data:{'id':id,'table':table,'_token':'<?php echo e(csrf_token()); ?>'},
               success:function(data) {
                 if (data.success) {
                   $('.custum-msg-success').addClass("animated fadeInRight").fadeIn().text(data.success)
                   currentElement.parent().css({"background":"#ccc"})
                   currentElement.parent().addClass("animated Shake").fadeOut(3000)
                   setTimeout(function() {
                     $('.custum-msg-success').removeClass("animated fadeInRight")
                     $('.custum-msg-success').addClass("animated fadeOutRight")
                   },7000)
                 }
               }
             })
           }else {
             return
           }
         })
     })

     </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>