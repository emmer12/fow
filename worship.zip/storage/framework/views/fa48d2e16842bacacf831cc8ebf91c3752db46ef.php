<style media="screen">
  .active{
    font-weight: bolder;
    color:#073e5d;
    background:#ddd
  }
  .drawer li{
    list-style: none
  }

</style>

<div class="drawer">
  <div class="drawer-header">
    <img width="100px" height="100px" src="/images/b9.jpg"  alt="Mezzo"><br>
    <h4 class="center-blo">Admin</h4>
  </div>
  <div class="drawer-body">
      <ul>
        <li>
          <a href="<?php echo e(route('admin.index')); ?>">Post Audio</a>
        </li>
        <li>
          <a href="<?php echo e(route('admin.index')); ?>">Audio List</span></a>
        </li>
        <li>
          <a href="/">Orders</a>
        </li>
        <li>
          <a href="/">Profiles</a>
        </li>
        <li>
          <a href="/">Settings</a>
        </li>
        <li>
            <a href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                         document.getElementById('logout-form').submit();">
                Logout
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>
        </li>
      </ul>
  </div>
</div>
<div class="bar">
  <span class="ti ti-menu"></span>
</div>
<script type="text/javascript">
  $('.bar span').click(function () {
    if ($(this).hasClass('ti-menu') ) {
      $(this).removeClass('ti-menu')
      $('.drawer').animate({
        left:'0px'
      })
      $(this).addClass('ti-close')
    }else {
      $(this).removeClass('ti-close')
      $('.drawer').animate({
        left:'-300px'
      })
      $(this).addClass('ti-menu')

    }
  })
</script>
