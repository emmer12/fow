<?php $__env->startSection("content"); ?>
   <div class="container">
     <div class="blog-nav ">
       <ul class="nav nav-tabs">
         <li class="nav-item">
           <a href="<?php echo e(route("blog.index")); ?>" class="nav-link">News</a>
         </li>
         <li class="nav-item">
           <a href="<?php echo e(route("fund-raise.index")); ?>" class="nav-link active-ms">Found Raise</a>
         </li>
         <li class="nav-item">
           <a href="<?php echo e(route("testimonies.index")); ?>" class="nav-link">Testimonial</a>
         </li>

       </ul>
     </div>
     <h4 class="heading"> Fund Raise</h4>
     <div class="row">
     <?php if(count($fund_raise) < 1): ?>
       <div class="alert alert-info" role="alert">
          Posts Not Found
       </div>
      <?php else: ?>
        <?php $__currentLoopData = $fund_raise; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fund_raise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-4 blog-design">
            <div class="card">
              <a href="<?php echo e(route('blog.show',$fund_raise->slug)); ?>">
                <img class="card-img top" src="/storage/uploads/images/<?php echo e($fund_raise->preview_image); ?>" width="100%" height="250px" alt="Card image cap">
              </a>
              <div class="card-block">
                <a href="#" class="btn btn-color pull-right">Fund Raise</a>
                <a href="<?php echo e(route('blog.show',$fund_raise->slug)); ?>">
                 <h4 class="card-title"><?php echo e($fund_raise->title); ?></h4>
                </a>
                <div class="blog-info-div">
                  <p class="card-text"><?php echo e($fund_raise->body); ?></p>
                  <span><i class="ti ti-time"> <?php echo e($fund_raise->created_at); ?></i></span>
                  <span class="pull-right"> <a href="<?php echo e(route('blog.show',$fund_raise->slug)); ?>">read more..</a> </span>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php endif; ?>
   </div>

 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>