<style media="screen">

</style>
<?php $__env->startSection("content"); ?>
  <?php if($isAdmin): ?>
      <?php echo $__env->make('inc/drawer-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php else: ?>
      <?php echo $__env->make('inc/drawer-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <?php endif; ?>
  <style media="screen">
  .profile{
    background: white;
    padding: 20px
  }
  .profile input{
    border:none;
    outline: none
  }
    .profile .profile-pic img {
      width: 120px;
      height: 120px;
      cursor: pointer;
      padding: 10px;

    }
    .profile .profile-pic{
      width:150px;
      padding: 10px;
      margin:0px auto;
      border:2px dashed grey
    }
    /* .profile .body{
      padding: 10px;
      background: white
    } */
  </style>
  <br>
   <div class="container">
     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-9">
          <div class="profile">
            <?php if(session('success')): ?>
              <div class="alert alert-success" role="alert">
               <?php echo e(session('success')); ?>

              </div>
            <?php endif; ?>
            <?php if(count($errors) > 0): ?>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger" role="alert">
                  <?php echo e($error); ?>

                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <form class="" action="<?php echo e(route("profile.update",$user->id)); ?>" method="post" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field("PATCH")); ?>

              <fieldset class="form-group profile-pic text-center">
                <label for="profile_picture"><img src="/storage/uploads/images/<?php echo e($user->profile_picture); ?>" alt=""> </label>
                <span class="edit"> <i class="glyphicon glyphicon-edit"></i> </span>
                <input value="" type="file" name="profile_picture" class="form-control hide"  id="profile_picture">
              </fieldset>
              <div class="body">
                <fieldset class="form-group<?php echo e($errors->has('firstname') ? ' has-error' : ''); ?>">
                  <label for="firstname">Firstname</label>
                  <input type="type" class="form-control" name="firstname" id="firstname" placeholder="Firstname"  value="<?php echo e($user->firstname); ?>">
                  <?php if($errors->has('firstname')): ?>
                    <span class="help-block ">
                      <strong><?php echo e($errors->first('firstname')); ?></strong>
                    </span>
                  <?php endif; ?>
                </fieldset>
                <fieldset class="form-group<?php echo e($errors->has('lastname') ? ' has-error' : ''); ?>">
                  <label for="lasstname">Lastname</label>
                  <input type="type" class="form-control" name="lastname" id="lasstname" placeholder="Lastname"  value="<?php echo e($user->lastname); ?>">
                  <?php if($errors->has('lastname')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('lastname')); ?></strong>
                      </span>
                  <?php endif; ?>
                </fieldset>
                <fieldset class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                  <label for="username">Username</label>
                  <input type="type" class="form-control" name="username" id="username" placeholder="Username"  value="<?php echo e($user->username); ?>">
                  <?php if($errors->has('username')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('username')); ?></strong>
                      </span>
                  <?php endif; ?>
                </fieldset>
                <fieldset class="form-group<?php echo e($errors->has('phoneNo') ? ' has-error' : ''); ?>">
                  <label for="phoneNo">Phone Number</label>
                  <input type="number" class="form-control" name="phoneNo" id="phoneNo" placeholder="Phone Number"  value="<?php echo e($user->phoneNo); ?>">
                  <?php if($errors->has('phoneNo')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('phoneNo')); ?></strong>
                      </span>
                  <?php endif; ?>
                </fieldset>
                <fieldset class="form-group<?php echo e($errors->has('state') ? ' has-error' : ''); ?>">
                  <label for="state">State</label>
                  <input type="string" class="form-control" name="state" id="state" placeholder="Phone Number"  value="<?php echo e($user->state); ?>">
                  <?php if($errors->has('state')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('state')); ?></strong>
                      </span>
                  <?php endif; ?>
                </fieldset>
                <fieldset class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                  <label for="email">Email</label>
                  <input type="email" class="form-control" name="email" id="email" placeholder="example@mail.com"  value="<?php echo e($user->email); ?>">
                  <?php if($errors->has('email')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('email')); ?></strong>
                      </span>
                  <?php endif; ?>
                </fieldset>
                <fieldset class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                  <label for="bio">Bio</label>
                  <textarea name="bio" rows="3" cols="10" class="form-control"  id='bio' ></textarea>
                  <?php if($errors->has('bio')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('bio')); ?></strong>
                      </span>
                  <?php endif; ?>
                </fieldset>
                <fieldset class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                  <label for="facebook-link">Facebook Link</label>
                  <input type="url" class="form-control" name="facebook_link" id="facebook-link" placeholder="facebook link"  value="<?php echo e($user->facebook_link); ?>">
                  <?php if($errors->has('facebook_link')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('facebook_link')); ?></strong>
                      </span>
                  <?php endif; ?>
                </fieldset>
                <fieldset class="form-group<?php echo e($errors->has('twitter') ? ' has-error' : ''); ?>">
                  <label for="twitter">Email</label>
                  <input type="text" class="form-control" name="twitter" id="twitter" placeholder="twitter username"  value="<?php echo e($user->twitter); ?>">
                  <?php if($errors->has('twitter')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('twitter')); ?></strong>
                      </span>
                  <?php endif; ?>
                </fieldset>
                <button type="submit" class="btn btn-primary">Update</button><br><br>
                <button type="button" class="btn btn-success">Change Password</button>
              </div>


            </form>
          </div>
       </div>
     </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>