<style media="screen">
  .category ul{
    margin:0px;
    background: white;
    padding: 10px;
    font-weight:700
  }
  .category ul li{
    list-style: none;
  }
  .category ul li a{
    display:block;
    //background:#ddd;
    padding:10px;
    margin:3px;
    border-bottom: 1px solid #073e5d
  }

</style>
<?php $__env->startSection("content"); ?>
   <div class="store-nav">
     <ul>
       <li><a href="<?php echo e(route("store-page")); ?>">Main store</a></li>
       <li> <a href="<?php echo e(route("store.books")); ?>">Books store</a> </li>
     </ul>
   </div>
    <div class="container">
      <div class="row">
        <form class="search-form storeSearch text-right" action="index.html" method="post">
          <input type="text" name="search" class=""  value="<?php echo e(old('search')); ?>" placeholder="search..." >
          <input type="submit" name="submit" value="GO" >
        </form>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="category">
            <h4 class="heading">Category <span class="ti ti-menu"></span> </h4>
            <ul>
              <?php $__currentLoopData = $bookCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route("store-category-page",str_slug($bookCategory->name,'-'))); ?>"> <span class="ti ti-angle-double-right"></span><?php echo e($bookCategory->name); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </div>
        <div class="col-md-8">
          <?php if(isset($count)): ?>
            <strong style="margin-left:15px">found  <?php echo e($count); ?> <span class="text-success"> (<?php echo e($thisCategory); ?>)</span> Result(s)</strong>
          <?php endif; ?>
          <div class="row">
            
            <?php if(count($books) < 1): ?>
               <div class="alert alert-info" role="alert">
                 No Books In the Store
               </div>
            <?php endif; ?>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-4 col-sm-6">
                <div class="book-shopping-card">
                  <a href="<?php echo e(route('single.book.show',$book->slug)); ?>">
                    <img src="/storage/uploads/images/<?php echo e($book->preview_image); ?>" width="100%" height="300px" alt="">
                  </a>
                  <div class="card-details">
                    <a href="/store/<?php echo e($book->slug); ?>" class="t-active"> <h4><?php echo e($book->title); ?></h4> </a>
                    <?php if($book->price): ?>
                      <span class="pull-right price"><b>&#x20A6;<?php echo e($book->price); ?></b></span>
                      <hr>
                      <button type="submit" class="btn btn-success btn-lg center-block" id="desk-show">Buy</span> </button>
                      <?php else: ?>
                      <a href="/storage/uploads/books/<?php echo e($book->file); ?>" class="btn btn-success btn-lg center-block desk-show" ><span class="ti ti-download"></span> </a>
                    <?php endif; ?>
                  </div>
                </div>
              </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

          </div>

        </div>
      </div>
  </div>
  <div class="container">
    <nav>
      <ul class="pager-custom">
        <?php echo e($books->links()); ?>

      </ul>
    </nav>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>