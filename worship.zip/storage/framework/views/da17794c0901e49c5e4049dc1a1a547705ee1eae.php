<?php $__env->startSection("content"); ?>
  <?php echo $__env->make('inc/drawer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <br>
   <div class="container">
     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-9">
         <div class="panel panel-default video-form">
           <div class="panel-heading" id="p-heading">
             <h4><strong>Post Audio<strong></h4>
           </div>
           <div class="panel-body">
             <?php if(session('success')): ?>
               <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

               </div>
             <?php endif; ?>
             <?php if(count($errors) > 0): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="alert alert-danger" role="alert">
                   <?php echo e($error); ?>

                 </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php endif; ?>
             <form method="POST" action="<?php echo e(route('admin-storeAudio')); ?>" enctype="multipart/form-data">
               <?php echo e(csrf_field()); ?>

               <fieldset class="form-group">
                 <label for="title">Audio Title</label>
                 <input value="<?php echo e(old('title')); ?>" type="text" name="title" class="form-control" id="title" placeholder="Audio Title ">
               </fieldset>
               <fieldset class="form-group">
                 <label for="discription">Audio Discription</label>
                 <textarea value="<?php echo e(old('discription')); ?>" name="discription" class="form-control" rows="3" cols="50"></textarea>
               </fieldset>
               <fieldset class="form-group">
                 <label for="lyrics">Lyrics</label>
                 <textarea value="<?php echo e(old('lyrics')); ?>" name="lyrics" class="form-control" rows="6" cols="60"></textarea>
               </fieldset>
               <fieldset class="form-group">
                 <label for="artist_name">Airtist Name</label>
                 <input value="<?php echo e(old('artist_name')); ?>" type="text" name="artist_name" class="form-control" id="artist_name" placeholder="Video Title ">
               </fieldset>
               <fieldset class="form-group">
                 <select class="form-control" name="author_id">
                   <option value="">Choose Registered Artist</option>
                   <?php $__currentLoopData = $worshipers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worshiper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($worshiper->id); ?>"><?php echo e($worshiper->name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
               </fieldset>
               <fieldset class="form-group">
                 <label for="p-image">Preview Image</label>
                 <div class="row">
                    <div class="col-lg-4">
                      <input value="<?php echo e(old('preview_image')); ?>" type="file" name="preview_image" class="dropify preview_image" id="p-image" >
                    </div>
                  </div>
               </fieldset>
               <fieldset class="form-group">
                 <label for="video">Audio</label>
                 <div class="row">
                    <div class="col-lg-4">
                      <input value="<?php echo e(old('audio')); ?>" type="file" name="audio" id="audio" class="dropify video" >
                    </div>
                  </div>
               </fieldset>
               <button type="submit" class="btn btn-primary">POST</button>
             </form>
           </div>
         </div>

       </div>
     </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>