<div class="footer-nav-container">
  <div class="container">
   <div class="row">
     <div class="col-md-3"></div>
    <div class="col-md-6">
      <ul class="center">
        <li> <a href="<?php echo e(route("page.about")); ?>">About Us</a></li>
        <li> <a href="<?php echo e(route("page.contact")); ?>">Contact Us</a></li>
        <li> <a href="<?php echo e(route("blog.index")); ?>">Must See</a></li>

      </ul>
    </div>
    <div class="col-md-3"></div>
  </div>
  </div>
 </div>
