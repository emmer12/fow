<?php $__env->startSection("content"); ?>
  <br>
   <div class="">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="fotorama" data-nav="thumbs" data-allowfullscreen="native">
            <a href="#"><img width="100%" src="/storage/uploads/images/<?php echo e($product->preview_image); ?>"  class="center-block" alt="Friends Of Worship"></a>
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a href="#"><img width="100%" src="/storage/uploads/images/<?php echo e($image->other_img); ?>" alt="Friends Of Worship"></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          </div>
              <!-- End Simple Lence Thumbnail -->

          <!-- End Simple Lence Gallery Container -->
          
        <div class="col-md-6">
          <div class="product-s-details">
            <h4 class="title"><?php echo e($product->product_title); ?></h4>
            as low as <span> <b>&#x20A6;<?php echo e($product->product_price); ?></b> </span>
            <hr>
            <h4><b>Category</b></h4>
            <a href="#"><?php echo e($product->category); ?></a>
            <h4> <b>Description</b> </h4>
            <p><?php echo e($product->product_discription); ?></p>
            <hr>
            <ul class="list-inline">
              <li> <span class="ti ti-facebook"> Share</span> </li>
              <li> <span class="ti ti-twitter"> Tweet</span> </li>
              <li></li>
              <hr>
              <div class="action">
                <form class="" action="<?php echo e(route('cart.store')); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                  <input type="hidden" name="product_price" value="<?php echo e($product->product_price); ?>">
                  <input type="hidden" name="product_title" value="<?php echo e($product->product_title); ?>">

                  <button type="submit" class="btn btn-success center-block desk-show" id="desk-show">Add To Cart <span class="ti ti-shopping-cart"></span> </button>
                </form>
              </div>
            </ul>
          </div>
        </div>
      </div>
    </div>
      <br>
    </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>