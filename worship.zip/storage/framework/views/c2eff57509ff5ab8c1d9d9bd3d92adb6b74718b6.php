<style media="screen">

  .testimonial{
    text-align:center;
    padding:30px 0 15px
  }
  .testimonial h6{
    font-weight:700
  }
  .testimonial img{
    border-radius:50%;
    margin:5px 0;
    height:60px;
    width:60px;
    box-shadow:0 2px 2px 0 transparent,0 1px 5px 0 rgba(0,0,0,.24),0 3px 1px -2px transparent
  }
   .testimonial .owl-theme .owl-controls .owl-page span{
     width:10px;height:10px
   }
</style>
<?php $__env->startSection("content"); ?>
   <div class="container">
     <div class="blog-nav ">
       <ul class="nav nav-tabs">
         <li class="nav-item">
           <a href="<?php echo e(route("blog.index")); ?>" class="nav-link">News</a>
         </li>
         <li class="nav-item">
           <a href="<?php echo e(route("fund-raise.index")); ?>" class="nav-link ">Found Raise</a>
         </li>
         <li class="nav-item">
           <a href="<?php echo e(route("testimonies.index")); ?>" class="nav-link active-ms">Testimonial</a>
         </li>

       </ul>
     </div>
     <h4>Testimonies</h4>
     <!-- testimonial -->
   	<div class="testimonial app-pages">
   		<div class="container">
        <?php if(count($testimonies) < 1): ?>
          <div class="alert alert-info" role="alert">
            No post Available
          </div>
          <?php else: ?>
            <div id="testimonial" class="owl-carousel owl-theme">
                <?php $__currentLoopData = $testimonies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimony): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                  <p><?php echo e($testimony->body); ?></p>
                  <img src="/images/testimonial.jpg" alt="">
                  <h6><?php echo e($testimony->title); ?></h6>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
   		</div>
   	</div>
   	<!-- end testimonial -->
 		</div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>