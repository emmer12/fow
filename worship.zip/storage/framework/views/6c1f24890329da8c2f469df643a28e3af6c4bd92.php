<style media="screen">
.play-time{
  top: -80px;
}

</style>
<?php $__env->startSection("content"); ?>
   <div class="">
     <div class="m-banner text-center">
       <div class="m-banner-c">
         <span class="glyphicon glyphicon-music "></span>
         <h4>MUSIC</h4>
       </div>
     </div>
   </div>
   <br>
     <div class="container">
       <div class="row">
         <?php $__currentLoopData = $music_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $music_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-md-4">
             <div class="m-div">
               <a href="<?php echo e(route("audio-show","$music_post->slug")); ?>" style="color:inherit">
                 <img src="/storage/uploads/images/<?php echo e($music_post->preview_image); ?>" alt="">
               </a>
               <audio src="/storage/uploads/audios/<?php echo e($music_post->music); ?>" class='audio-<?php echo e($music_post->id); ?>' ></audio>
               <div class="pull-right" id="title">
                 <a href="<?php echo e(route("audio-show","$music_post->slug")); ?>" style="color:inherit">
                   <h4><?php echo e($music_post->title); ?></h4>
                 </a>
               </div>
               <div class="audio-cont" style="position:absolute;right:30px;top:75px" >
                 <span class="ti ti-control-play audio-p" data-id='<?php echo e($music_post->id); ?>'></span>
                 <span>5:00</span>
               </div>
             </div>
           </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       </div>
     </div>
   <nav>
     <ul class="pager">
       <li><a href="#">Previous</a></li>
       <li><a href="#">Next</a></li>
     </ul>
   </nav>
   <ol class="breadcrumb" style="margin-bottom: 5px;">
     <li><a href="/">Home</a></li>
     <li class="active">Music</li>
   </ol>
   <a href="#har_page" class="har_top ti ti-arrow-up har_go"></a>
   <ul>
      <li><a href="05_shortcodes.html#labels"><i class="ti ti-control-pause"></i>Labels</a></li>
      <li><a href="05_shortcodes.html#alerts"><i class="ti ti-alert-music"></i>Alerts</a></li>
      <li><a href="05_shortcodes.html#lightbox"><i class="ti ti-layout-slider-alt"></i>Lightbox</a></li>
      </ul>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>