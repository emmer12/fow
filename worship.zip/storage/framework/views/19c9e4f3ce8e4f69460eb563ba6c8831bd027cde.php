<style media="screen">

</style>
<?php $__env->startSection("content"); ?>
  <?php echo $__env->make('inc/drawer-w', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <br>
   <div class="container">
     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-9">
         <div class="panel panel-default video-form">
           <div class="panel-heading" id="p-heading">
             <h4> <strong>Post Videos</strong></h4>
           </div>
           <div class="panel-body">
             <?php if(session('success')): ?>
               <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

               </div>
             <?php endif; ?>
             <?php if(count($errors) > 0): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="alert alert-danger" role="alert">
                   <?php echo e($error); ?>

                 </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             <?php endif; ?>
             <form method="POST" action="<?php echo e(route('admin-storeVideo')); ?>" enctype="multipart/form-data">
               <?php echo e(csrf_field()); ?>

               <fieldset class="form-group">
                 <label for="title">Video Title</label>
                 <input value="<?php echo e(old('title')); ?>" type="text" name="title" class="form-control" id="title" placeholder="Video Title ">
               </fieldset>
               <fieldset class="form-group">
                 <label for="formGroupExampleInput2">Video Discription</label>
                 <textarea value="<?php echo e(old('discription')); ?>" name="discription" class="form-control" rows="3" cols="50"></textarea>
               </fieldset>
               <fieldset class="form-group">
                 <label for="formGroupExampleInput2">Lyrics</label>
                 <textarea value="<?php echo e(old('lyrics')); ?>" name="lyrics" class="form-control" rows="6" cols="60"></textarea>
               </fieldset>
               <fieldset class="form-group">
                 <label for="p-image">Preview Image</label>
                 <div class="row">
                    <div class="col-lg-4">
                      <input value="<?php echo e(old('preview_image')); ?>" type="file" name="preview_image" class="dropify preview_image" id="p-image" >
                    </div>
                  </div>
               </fieldset>
               <fieldset class="form-group">
                 <label for="video">Video</label>
                 <div class="row">
                    <div class="col-lg-4">
                      <input value="<?php echo e(old('video')); ?>" type="file" name="video" id="video" class="dropify video" >
                    </div>
                  </div>
               </fieldset>
               <button type="submit" class="btn btn-primary">POST</button>
             </form>
           </div>
         </div>

       </div>
     </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>