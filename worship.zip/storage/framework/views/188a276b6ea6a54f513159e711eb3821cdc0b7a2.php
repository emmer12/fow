<?php $__env->startSection('content'); ?>
  <br>
<div class="container">
    <div class="row">
        <div class="col-md-5 col-md-offset-4">
            <div class="panel panel-default log-form">
                <div class="login-form-haed panel-heading">
                  <h4>FRIENDS OF WORSHIP</h4>
                  <p>ADMIN LOGIN</p>
                  <?php if(session('msg')): ?>
                    <div class="alert alert-danger" role="alert">
                      <span class="ti ti-control-play"></span>
                      <?php echo e(session('msg')); ?>

                    </div>
                  <?php endif; ?>
                </div>

                <div class="panel-body ">
                  <div class="login-form">
                    <form  method="POST" action="<?php echo e(route('admin.login')); ?>" >
                      <?php echo e(csrf_field()); ?>

                      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
                      <fieldset class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label for="email">Email</label>
                        <input type="email" name="email" class="form-control" id="email" placeholder="example@mail.com">
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                      </fieldset>
                      <fieldset class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <label for="password">Password</label>
                        <input type="password" name="password" class="form-control" id="password" placeholder="******">
                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                      </fieldset>
                      <div class="form-group">
                          <div class="col-md-6 col-md-offset-4">
                              <div class="checkbox">
                                  <label>
                                      <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                  </label>
                              </div>
                          </div>
                      </div>
                      <button type="submit" class="btn btn-primary center-block">LOGIN</button><br>
                    </form>
                  </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>