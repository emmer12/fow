<?php $__env->startSection("content"); ?>
  <div class="podcast-player">
    <div class="podcast-container">
      <audio class="p-play" style="color:#111" src="/storage/uploads/podcasts/<?php echo e($podcast->podcast); ?>" controls></audio>
      <h4 class="main-title"><?php echo e($podcast->title); ?></h4>
      <img class="podcast-preview" src="/storage/uploads/images/<?php echo e($podcast->preview_image); ?>" height="100%" width="100%" alt="...">
      <div class="podcast-footer">
        <div class="details">
          <div class="p-info-d">
            <?php echo e($podcast->discription); ?>

          </div>
            <img src="/storage/uploads/images/<?php echo e($podcast->author_pic); ?>" width="100%" height="100px" alt="friends Of Worship">
            <div class="dis">
              <b class="main-author"><?php echo e($podcast->author); ?></b>
          </div>
        </div>
        <div class="controls">
        <ul>
          <li> <span class="ti ti-control-play main-p-play"></span> </li>
          <li> <span class="ti ti-info p-info" title="Podcast Info"></span> </li>
          <style media="screen">
            .p-info-d{
              padding: 10px;
              border-radius: 3px;
              color: white;
              bottom: 100px;
              position:relative;
              width: 100%;
              height: 100px;
              overflow: scroll;
              background: #222;
              display:none
            }
          </style>

          <li><a style="font-size:20px;" class="download-p" href="/storage/uploads/podcasts/<?php echo e($podcast->podcast); ?>" download><span class="ti ti-download"></span></a></li>
        </ul>
      </div>
      </div>

    </div>
  </div>
  <div class="container">
    <div class="row">
      <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route("show.details",[$episode->podcast_epic_id,$episode->slug])); ?>">
          <div class="col-md-4 podcast-list">
            <img src="/storage/uploads/images/<?php echo e($episode->preview_image); ?>" width="100%" height="100px" alt="friends Of Worship">
            <div class="details">
              <h4> <a href="#"><?php echo e($episode->title); ?></a></h4>
              <h5><b><?php echo e($episode->author); ?></b> </h5>
              <span data-podcast="/storage/uploads/podcasts/<?php echo e($episode->podcast); ?>" data-title="<?php echo e($episode->title); ?>" data-author="<?php echo e($episode->author); ?>" data-dp="/storage/uploads/images/<?php echo e($episode->preview_image); ?>" class="ti ti-control-play podcast-play"></span>
            </div>
          </div>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  </div>
  <br><br>

  
  <br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>