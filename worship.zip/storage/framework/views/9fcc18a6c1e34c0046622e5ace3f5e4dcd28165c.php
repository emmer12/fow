<?php $__env->startSection("content"); ?>
  <style media="screen">

  .cart-con table tr td {
    line-height:100px;
  }
  .cart-con table tr td input{
    line-height:25px;
  }
  .cart-con span{
    cursor: pointer;
    font-weight:700
  }

  </style>
  <div class="">
    <div class="s-banner text-center">
      <div class="m-banner-c">
        <span class="glyphicon glyphicon-shopping-cart"></span>
        <h4 >Cart</h4>
      </div>
    </div>
  </div>
  <br>

    <div class="container">
      <div class="alert alert-info" role="alert">
        <?php echo e(Cart::count()); ?> item(s) in the cart
      </div>
      <div class="row">
        <div class="col-md-12 col-sm-12">
          
          <?php if(Cart::count() < 1): ?>
          <?php else: ?>
           <div class="cart-con">
             <div class="table-responsive">
               <table class="table">

                   <thead>
                     <tr>
                       <th>Image</th>
                       <th>Product</th>
                       <th>Quantity</th>
                       <th>Price</th>
                       <th>Subtotal</th>
                     </tr>
                 </thead>
                 <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tbody>
                   <tr>
                     <td> <a href="<?php echo e(route('store-show',$cart->model->slug)); ?>"> <img src="/storage/uploads/images/<?php echo e($cart->model->preview_image); ?>" class="img-fluid pull-xs-left" alt="..."></a></td>
                     <td><a href="<?php echo e(route('store-show',$cart->model->slug)); ?>"><?php echo e($cart->model->product_title); ?></a></td>
                     <td>
                       <form class="" action="<?php echo e(route("cart.update",$cart->rowId)); ?>" method="post">
                         <?php echo e(csrf_field()); ?>

                         <button type="button" class="btn btn-primary" onclick="var result = document.getElementById('qty-<?php echo e($cart->model->id); ?>'); var qty = result.value; if( !isNaN( qty) &amp;&amp; qty &gt; 1 ) result.value--;return false;"><span class="ti ti-minus"></span></button>
                         <input type="text" maxlength="8" name="qty" value="<?php echo e($cart->qty); ?>" id="qty-<?php echo e($cart->model->id); ?>">
                         <button type="button" class="btn btn-primary" onclick="var result = document.getElementById('qty-<?php echo e($cart->model->id); ?>'); var qty = result.value; if( !isNaN( qty)) result.value++;return false;" ><span class="ti ti-plus"></span></button>
                         <button type="submit" name="button" class="btn btn-success">Update</button>
                       </form>
                     </td>
                     <td>&#x20A6;<?php echo e($cart->model->product_price); ?></td>
                     <td>&#x20A6;<?php echo e($cart->model->product_price * $cart->qty); ?></td>
                     <form class="" action="<?php echo e(route("cart.destroy",$cart->rowId)); ?>" method="post">
                       <?php echo e(csrf_field()); ?>

                         <td><label for="submit<?php echo e($cart->rowId); ?>" class="ti ti-close"> </label> </td>
                         <input type="submit" class="hidden" id="submit<?php echo e($cart->rowId); ?>" name="submit" value="">
                     </form>

                   </tr>
                 </tbody>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </table>
             </div>
           </div>
         <?php endif; ?>
             
             <hr>
             <div class="container">
               <div class="row">
                 <?php if(Cart::count() < 1): ?>
                   <div class="">
                     <a class="btn btn-primary" href="<?php echo e(route('store-page')); ?>" role="button"> <span class="ti ti-arrow-left"></span>Back to Store</a>
                   </div>
                  <?php else: ?>
                 <div class="col-md-6" style="margin-bottom:10px">
                   <a class="btn btn-primary" href="<?php echo e(route('store-page')); ?>" role="button"> <span class="ti ti-arrow-left"></span>Back to Store</a>
                   <a class="btn btn-success" href="<?php echo e(route("store.checkout")); ?>" role="button"> Checkout</a>
                 </div>
                 <div class="col-md-6">
                   <div class="cart-payment-details">
                     <h3 class="text-center">Your Order</h3>
                     <table class="table">
                       <thead>
                         <tr>
                           <th> <h4>Products</h4> </th>
                           <th> <h4>Subtotal</h4> </th>
                         </tr>
                       </thead>

                           <tbody>
                       <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                               <td><?php echo e($cart->model->product_price); ?> X <?php echo e($cart->qty); ?></td>
                               <td>&#x20A6;<?php echo e($cart->model->product_price * $cart->qty); ?></td>
                             </tr>
                             <tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <td>Shipping</td>
                               <td>&#x20A6;2000</td>
                             </tr>
                             <hr>
                             <td> <h4><b>Total</b></h4> </td>
                             <td><h4 style="color:#073e5d;font-weight:700">&#x20A6;<?php echo e(Cart::subtotal()); ?></h4></td>
                           </tr>
                         </tbody>


                   </table>
                   <a href="<?php echo e(route("store.checkout")); ?>" class="btn btn-success center-block " style="color:white;text-decoration:none;display:block;width:100px">CHECKOUT</a>
                 </div>
                 </div>
               <?php endif; ?>
               </div>
             </div>
        </div>
    </div>
  </div>
  <hr>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>