<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('beautymail::templates.sunny.heading' , [
        'heading' => 'Hello!',
        'level' => 'h1',
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('beautymail::templates.minty.contentStart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <p>You Are onyour way to confirm your email address <?php echo e($user); ?></p>

    <?php echo $__env->make('beautymail::templates.minty.contentEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('beautymail::templates.minty.button',
   ['text' => 'Verify Email', 'link' => '#'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('beautymail::templates.minty', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>