<style media="screen">

</style>
<?php $__env->startSection("content"); ?>
  <?php echo $__env->make('inc/drawer-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <br>
   <div class="container">
     <div class="row">
       <div class="col-md-3">
       </div>
        <div class="col-md-9">
          <div class="contain" style="background:white;padding:10px">

          <div class="heading">
            <h4>Blog Posts</h4>
          </div>
          <div class="table-responsive">
          <table class="table " >
            <thead>
              <tr>
                <th>S/N</th>
                <th>Blog Title</th>
                <th>Display Image</th>
                <th>Author</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $blogPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td></td>
                  <td>
                    <a href="<?php echo e(route('blog.show',$blogPost->slug)); ?>">
                      <h4 class="card-title"><?php echo e($blogPost->title); ?></h4>
                    </a>
                  </td>
                  <td> <img src="/storage/uploads/images/<?php echo e($blogPost->preview_image); ?>" width="150px" height="100px" alt=""> </td>
                  <td> <a href="#"><?php echo e($blogPost->author()->firstname); ?> <?php echo e($blogPost->author()->lastname); ?></a> </td>
                  <td>
                    <form class="approve-form<?php echo e($blogPost->id); ?>" action="<?php echo e(route('admin-blog-approval')); ?>" method="post">
                      <?php echo e(csrf_field()); ?>

                      <input type="hidden" name="post_id" value="<?php echo e($blogPost->id); ?>">
                      <input type="checkbox" name="status" <?php echo e($blogPost->approved ? "checked" : ""); ?>  >
                    </form>
                  </td>
                  <td>
                    <?php if($blogPost->approved): ?>
                      <button type="button" class="btn btn-danger approve-act" data_id="<?php echo e($blogPost->id); ?>"> <span class="ti ti-thumb-down"></span> </button>
                      <?php else: ?>
                      <button type="button" class="btn btn-success approve-act" data_id="<?php echo e($blogPost->id); ?>" > <span class="ti ti-thumb-up"></button>

                    <?php endif; ?>
                    <button type="button" class="btn btn-primary"> <span class="ti ti-eraser"></button>
                    <button type="button" class="btn btn-danger"> <span class="ti ti-trash"></button>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
            <tfoot>
              <tr>
                <td></td>
                <td></td>
                <td></td>
                <td colspan=6>
                  <ul class="pager">
                    <?php echo e($blogPosts->links()); ?>

                  </ul>
             </td>
            </tr>
            </tfoot>

          </table>
         </div>
        </div>

        </div>

       </div>
     </div>
   </div>
   <br>
   <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>