<style media="screen">
.play-time{
  top: -80px;
}
.custom-modal{
  display:none;
  position:absolute;
  top:0px;
  width:100%;
  z-index: 999;
}
.modal-dialog{
//  background: white
}
.team-i-details{
  background: rgba(255, 250, 255,0.9);
  padding: 10px;
  margin: 15px;
}


</style>
<?php $__env->startSection("content"); ?>
   <div class="">
     <div class="m-banner text-center">
       <div class="m-banner-c">
         <span class="glyphicon glyphicon-music "></span>
         <h4>MUSIC</h4>
       </div>
     </div>
   </div>
   <br>
     <div class="container">
       <div class="row">
         <button type="button" class="btn btn-primary pull-left"> <a href="<?php echo e(route('fow.all.tracks')); ?>">See All Audio</a> </button>
         <form class="search-form storeSearch text-right" action="<?php echo e(route("audio.search")); ?>" method="post">
           <?php echo e(csrf_field()); ?>

           <input type="text" name="search" class=""  value="<?php echo e(old('search')); ?>" placeholder="search..." >
           <input type="submit" name="submit" value="GO" >
         </form>
       </div>
       <div class="row">
           <?php if(isset($searchMode)): ?>
             <?php if(isset($audios)): ?>
               <?php $__currentLoopData = $audios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $music_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="col-md-4 col-sm-6">
                   <div class="m-div player">
                     <a href="<?php echo e(route("audio-show","$music_post->slug")); ?>" style="color:inherit">
                       <img src="/storage/uploads/images/<?php echo e($music_post->preview_image); ?>" alt="">
                     </a>
                     <audio src="/storage/uploads/audios/<?php echo e($music_post->music); ?>" ids="<?php echo e($music_post->id); ?>" class='audio-<?php echo e($music_post->id); ?>' ></audio>
                     <div class="pull-right audeo-title" id="title">
                       <a href="<?php echo e(route("audio-show","$music_post->slug")); ?>" style="color:inherit">
                         <h4><?php echo e($music_post->title); ?></h4>
                       </a>
                     </div>
                     <div class="audio-cont" style="position:absolute;right:30px;top:75px" >
                       <small class="name-artist" data-id='<?php echo e($music_post->id); ?>'><?php echo e($music_post->user->firstname); ?> <?php echo e($music_post->user->lastname); ?></small>
                       <span class="ti ti-control-play audio-p" data-id='<?php echo e($music_post->id); ?>'></span>
                       <span class="duration<?php echo e($music_post->id); ?>"></span>
                     </div>
                   </div>


                   <div class="artist-info artist-info-<?php echo e($music_post->id); ?>">
                     <span class="ti ti-close pull-right close"></span>
                     <div class="header">
                       <img src="/storage/uploads/images/<?php echo e($music_post->user->profile_picture); ?>" height="50px" width="50px"   alt="">
                     </div>
                     <div class="details">
                       <strong >@ <?php echo e($music_post->user->username); ?></strong><br><br>
                       <a href="<?php echo e(route("artist-profile",'@'.$music_post->user->username )); ?>" class="btn btn-success">Details</a>
                     </div>
                   </div>

                 </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php else: ?>
                 <div class="alert alert-info" role="alert">
                   <?php echo e($notFound); ?>

                 </div>
             <?php endif; ?>
             <?php else: ?>
               <?php $__currentLoopData = $worshipers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worshiper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="col-md-3 col-sm-6">
                   <a href="<?php echo e(route('fow.tracks',$worshiper->id)); ?>">
                     <div class="team-div">
                       <img src="/storage/uploads/images/<?php echo e($worshiper->profile_picture); ?>" height="200px" width="100%" alt="">
                       <div class="team-details">
                         <a href="<?php echo e(route("artist-profile",'@'.$worshiper->username )); ?>"><h5> <strong>@ <?php echo e($worshiper->username); ?></strong></h5></a>
                         <a href="<?php echo e(route("fow.tracks","$worshiper->id")); ?>" class="btn btn-primary" data-id="<?php echo e($worshiper->id); ?>"> <span class="ti ti-link"></span> </a>
                       </div>
                     </div>
                   </a>
                 </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>

         

       </div>
     </div>
     <br>
     <div class="overlay">

     </div>
     
   
    <script type="text/javascript">
      $(document).ready(function () {
        var aud=$('audio');
        $.each(aud,function(x,y) {
          $("audio")[x].addEventListener('loadedmetadata',function() {
          var id=$(this).attr("ids");
          var duration_min=Math.floor($('.audio-'+id)[0].duration/60)
          var duration_sec=Math.floor($('.audio-'+id)[0].duration-duration_min * 60)
          if (duration_min < 10) {
            duration_min = "0" + duration_min
          }
          if (duration_sec < 10) {
            duration_sec = "0" + duration_sec
          }
          console.log(duration_min);
          var timeft=duration_min + ":" + duration_sec
          $(".duration"+id).html(timeft)
      })
    })
      })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>