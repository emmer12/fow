<style media="screen">
  .category ul{
    margin:0px;
    background: white;
    padding: 10px;
    font-weight:700
  }
  .category ul li{
    list-style: none;
  }
  .category ul li a{
    display:block;
    //background:#ddd;
    padding:10px;
    margin:3px;
    border-bottom: 1px solid #073e5d
  }
  .store-nav{
    background: #ddd;
    margin:5px;

  }
  .store-nav ul li{
    display:inline-block;
  }
  .store-nav ul li a{
    padding: 10px 15px;
    background:#073e5d;
    color: white;
    font-weight: 700

  }
</style>
<?php $__env->startSection("content"); ?>
   <div class="store-nav">
     <ul>
       <li><a href="<?php echo e(route("store-page")); ?>">Main store</a></li>
       <li> <a href="<?php echo e(route("store.books")); ?>">Books store</a> </li>
     </ul>
   </div>
    <div class="container">
      <div class="row">
        <form class="search-form storeSearch text-right" action="index.html" method="post">
          <input type="text" name="search" class=""  value="<?php echo e(old('search')); ?>" placeholder="search..." >
          <input type="submit" name="submit" value="GO" >
        </form>
      </div>
      <div class="row">
        
        <div class="col-md-12">
          <?php if(isset($count)): ?>
            <strong style="margin-left:15px">found  <?php echo e($count); ?> <span class="text-success"> (<?php echo e($category); ?>)</span> Result(s)</strong>
          <?php endif; ?>
          <div class="row">
            
            <?php if(count($products) < 1): ?>
               <div class="alert alert-info" role="alert">
                 No product In the Store
               </div>
            <?php endif; ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
            
              <!-- Start-single-product -->
              <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 shop-mar-bottom">
                  <div class="product-single-wrap hover">
                      <div class="single-product">
                          <div class="ribbon red"><span>sale</span></div>
                          <div class="image">
                            <a href="<?php echo e(route('store-show',"$product->slug")); ?>">
                              <img src="/storage/uploads/images/<?php echo e($product->preview_image); ?>" width="100%" height="300px" alt="">
                            </a>
                          </div>
                          <div class="single-content">
                              <div class="brand">New</div>
                              <div class="title">
                                  <a href="<?php echo e(route('store-show',"$product->slug")); ?>"><?php echo e($product->product_title); ?></a>
                              </div>

                          </div>
                          <div class="prices">
                              <div class="price-prev"><?php echo e($product->discount_price); ?></div>
                              <div class="price-current present-price pull-right"><?php echo e($product->product_price); ?></div>
                          </div>

                          <div class="hover-area">
                              <div class="add-cart-button">
                                <form class="" action="<?php echo e(route('cart.store')); ?>" method="post">
                                  <?php echo e(csrf_field()); ?>

                                  <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                  <input type="hidden" name="product_price" value="<?php echo e($product->product_price); ?>">
                                  <input type="hidden" name="product_title" value="<?php echo e($product->product_title); ?>">

                                  <button type="submit" class="btn btn-success center-block desk-show hidden-xs" id="desk-show">Add To Cart <span class="ti ti-shopping-cart"></span> </button>
                                  <button type="submit" class="btn btn-success center-block hidden-lg hidden-md hidden-sm">Add To Cart <span class="ti ti-shopping-cart"></span> </button>
                                </form>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>

              <!-- End-single-product -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </div>

        </div>
      </div>
  </div>
  <div class="container">
    <nav>
      <ul class="pager-custom">
        <?php echo e($products->links()); ?>

      </ul>
    </nav>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>