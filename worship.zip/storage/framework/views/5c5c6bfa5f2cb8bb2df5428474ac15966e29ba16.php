<?php $__env->startSection("content"); ?>
  <style media="screen">
    .down-success img+.content{
      display:inline-block;
      width: auto;
      padding: 20px;
    }
    .down-success h2{
      color: #444
    }

  </style>
  <div class="container">
    <div class="well down-success">
      <img src="/images/congrat.png" alt="friends of worship:congrat">
      <div class="content">
        <h2 class="display-3">Thanks For Downloading</h2>
        <h3 class="display-3"><?php echo e($title); ?></h3>
        <a class="a" href="<?php echo e(route('team-page')); ?>">
          <button type="button" class="btn btn-primary">Download More</button>
        </a>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>