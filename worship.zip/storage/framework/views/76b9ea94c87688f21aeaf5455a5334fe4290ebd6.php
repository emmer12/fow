<?php $__env->startSection("content"); ?>
   <div class="container">
     <h4 class="heading">Latest Haps</h4>
     <div class="row hasModel">
       <?php if(count($haps) > 0): ?>
         <?php $__currentLoopData = $haps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-md-4 " >
             <div class="card blog-design" style="margin-left:3px;">
               <?php if($hap->display_pic=="default.jpg"): ?>
                 heool
                 <?php else: ?>
                   <a href="<?php echo e($hap->link); ?>" target="_blank" >
                     <img class="card-img top" src="/storage/uploads/images/<?php echo e($hap->display_pic); ?>" width="100%" height="250px" alt="Card image cap">
                   </a>
               <?php endif; ?>
               <div class="card-block">
                 <a href="#">
                   <h4 class="card-title"><?php echo e($hap->title); ?></h4>
                 </a>
                 <div class="blog-info-div">
                   <p class="card-text"><?php echo e($hap->body); ?></p>
                   <span><i class="ti ti-time"> <?php echo e($hap->date); ?> <?php echo e($hap->time); ?></i></span>
                   <span class="pull-right"> <b>&#x20A6; <?php echo e($hap->price); ?></b> </span>
                 </div>
                 <hr>
                 <button type="button" class="btn btn-default show-model" data-id="<?php echo e($hap->id); ?>"><span class="ti ti-eye"></span> View Details</button>
                 <a href="<?php echo e($hap->link); ?>" target="_blank" class="btn btn-success pull-right"> Book Now</a>
               </div>
             </div>
           </div>


           <div id="myModal" style="overflow:scroll" class="modal modal-custom-dynamic modal<?php echo e($hap->id); ?>"  tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
             <div class="modal-dialog modal-lg" >
               <div class="modal-content">
                 <div class="modal-header">
                   <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                   </button>
                   <h4 class="modal-title" id="myModalLabel"><?php echo e($hap->title); ?></h4>
                 </div>
                 <div class="modal-body">
                   <div class="" style="height:150px;width:100%">
                     <a href="<?php echo e($hap->link); ?>" target="_blank" >
                       <img class="card-img top" src="/storage/uploads/images/<?php echo e($hap->display_pic); ?>" width="100%" height="250px" alt="Card image cap">
                     </a>
                   </div>
                   <h4><span class="ti ti-layout-grid2"></span> Description</h4>
                   <?php echo e($hap->description); ?>

                   <hr>
                   <h4><span class="ti ti-location-pin"></span> Venue</h4>
                   <?php echo e($hap->venue); ?>

                   <hr>
                   <h4><span class="ti ti-time"></span> date & time</h4>
                   <?php echo e($hap->date); ?> <?php echo e($hap->time); ?>

                   <hr>
                   <h4><span class="ti ti-money"></span> Price</h4>
                   <b>&#x20A6; <?php echo e($hap->price); ?></b>
                 </div>
                 <div class="modal-footer">
                   <a href="<?php echo e($hap->link); ?>" target="_blank" class="btn btn-success">Book now</a>
                 </div>
               </div>
             </div>
           </div>

       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php else: ?>
           <div class="alert alert-info" role="alert">
             No Haps Found
           </div>
       <?php endif; ?>



     </div>
     <nav>
       <ul class="pager">
         <?php echo e($haps->links()); ?>

       </ul>
     </nav>
   </div>
   <div class="overlay"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>