<?php $__env->startSection("content"); ?>
   <div class="container">
       <form id="initial" class="">
         <fieldset class="form-group">
           <label for="formGroupExampleInput">Example label</label>
           <input type="text" class="form-control required" name="inp1" id="formGroupExampleInput"  placeholder="Example input">
         </fieldset>
         <fieldset class="form-group">
           <label for="formGroupExampleInput2">Another label</label>
           <input type="text" class="form-control required" name="inpt2" id="formGroupExampleInput2" placeholder="Another input">
         </fieldset>
         <input type="submit" name="" value="submit">
       </form>
       <button class="btn btn-primary" data-toggle="modal" data-target="#modal-1">Large modal</button>
       <var><div class="modal fade" id="modal-1">
         <div class="modal-dialog" role="document">
           <div class="modal-content">
             <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
                 <span class="sr-only">Close</span>
               </button>
               <h4 class="modal-title">heo</h4>
             </div>
             <div class="modal-body">
               <p>One fine body&hellip;</p>
             </div>
             <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               <button type="button" class="btn btn-primary">Save changes</button>
             </div>
           </div><!-- /.modal-content -->
         </div><!-- /.modal-dialog -->
       </div><!-- /.modal --></var>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>