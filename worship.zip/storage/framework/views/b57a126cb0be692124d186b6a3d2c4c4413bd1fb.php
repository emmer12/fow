<style media="screen">

</style>
<?php $__env->startSection("content"); ?>
  <?php echo $__env->make('inc/drawer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <br>
   <div class="container">
     <div class="row">
       <div class="col-md-3">
       </div>
       <div class="col-md-9">
         <div class="panel panel-default video-form">
           <div class="panel-heading " id="p-heading">
             <h4 class=""> <strong>Worshippers</strong> </h4>
           </div>
           <div class="panel-body">
             <?php if(session('success')): ?>
               <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

               </div>
             <?php endif; ?>
             <?php if(count($errors) > 0): ?>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="alert alert-danger" role="alert">
                   <?php echo e($error); ?>

                 </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             <?php endif; ?>
            <div class="">
              <?php if(count($worshipers) < 1): ?>
                <div class="alert alert-info" role="alert">
                  No Worshippers Yet
                </div>
               <?php else: ?>
                 <h5><?php echo e(count($worshipers)); ?> has Worshippers</h5>

                 <ul class="list-group">
                <?php $__currentLoopData = $worshipers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worsipper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item" style="margin:5px"><?php echo e($worsipper->name); ?> <span style="background:#ddd;padding:10px;border-radius:100%" class="opener-multi ti ti-angle-down pull-right" data-id="<?php echo e($worsipper->id); ?>"></span> </li>
                    <div class="mobile-sub-menu mobile-sub-menu<?php echo e($worsipper->id); ?>">
                      <div class="text-center">
                        <img src="/storage/uploads/images/<?php echo e($worsipper->profile_image); ?>" class="avater"  alt="">
                        <hr>
                        <strong>Name::</strong><?php echo e($worsipper->name); ?><br>
                        <strong>Email Address::</strong> <a href="mail:<?php echo e($worsipper->email); ?>"><?php echo e($worsipper->email); ?></a><br>
                        <strong>Phone Number::</strong> <a href="tel:<?php echo e($worsipper->phoneNo); ?>"><?php echo e($worsipper->phoneNo); ?></a> <br>
                        <strong>Location::</strong><?php echo e($worsipper->location); ?><br>
                        <strong>Date of birth::</strong><?php echo e($worsipper->b_date); ?><br>
                        <strong> about::</strong><?php echo e($worsipper->about); ?><br>
                        <hr>
                        <h4>Track</h4>
                        <audio src="/storage/uploads/audios/<?php echo e($worsipper->track); ?>" controls preload='auto'></audio>
                      </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              <?php endif; ?>
            </div>
           </div>
         </div>

       </div>
     </div>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>