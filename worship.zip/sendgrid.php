<!-- this is send grid SMTP credencials  -->
MAIL_DRIVER=smtp
MAIL_HOST=smtp.sendgrid.net
MAIL_PORT=[ssl=>468;tls/unsecure=>25,587]
MAIL_USERNAME=friendsofworship0011
MAIL_PASSWORD	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
MAIL_ENCRYPTION=null
