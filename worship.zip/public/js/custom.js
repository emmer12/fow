$(".audio-p").click(function () {
  var id=$(this).attr('data-id')
  if ($(this).hasClass("ti-control-play")) {
    $(this).addClass("ti-control-pause audio-p")
    $(this).removeClass("ti-control-play audio-p")
    $('.audio-'+id)[0].play();
    return
  }else {
    $(this).addClass("ti-control-play audio-p")
    $(this).removeClass("ti-control-pause audio-p")
    $('.audio-'+id)[0].pause();
    return
  }
})
$(".video-p").click(function () {
  var id=$(this).attr('data-id')
  if ($(this).hasClass("ti-control-play")) {
    $(this).addClass("ti-control-pause audio-p")
    $(this).removeClass("ti-control-play audio-p")
    $('.overlay,.close-vid').fadeIn()
    $(".vid-display-con-"+id).fadeIn()
    $(".vid-display-con .video-p").removeClass("ti-control-play audio-p")
    $(".vid-display-con .video-p").addClass("ti-control-pause");
    $('.video-'+id)[0].play();
    return
  }else {
    $(this).addClass("ti-control-play audio-p")
    $(this).removeClass("ti-control-pause audio-p")
    $('.video-'+id)[0].pause();
    return
  }
})
$(".overlay,.close-vid").click(function () {
  $('.overlay').fadeOut();
  $('.vid-display-con').fadeOut()
  $(".play-time .video-p").removeClass("ti-control-pause")
  $(".play-time .video-p").addClass("ti-control-play")
  $('video').load()
})

// toggle disription and video or audio details

$("span.opener").on("click", function(){
  var p1=$(this).parent()
  var p2=p1.parent()
    var menuopener = $(this);
    if (menuopener.hasClass("ti-angle-down")) {
       p2.find('.mobile-sub-menu').slideDown();
       menuopener.removeClass('ti-angle-down');
       menuopener.addClass('ti-angle-up');
    }
    else
    {
       p2.find('.mobile-sub-menu').slideUp();
       menuopener.removeClass('ti-angle-up');
       menuopener.addClass('ti-angle-down');
    }
    return false;
});

$("span.opener-multi").on("click", function(){
  var p1=$(this).parent()
  var p2=p1.parent()
  var id=$(this).data('id');
    var menuopener = $(this);
    if (menuopener.hasClass("ti-angle-down")) {
       p2.find('.mobile-sub-menu'+id).slideDown();
       menuopener.removeClass('ti-angle-down');
       menuopener.addClass('ti-angle-up');
    }
    else
    {
       p2.find('.mobile-sub-menu'+id).slideUp();
       menuopener.removeClass('ti-angle-up');
       menuopener.addClass('ti-angle-down');
    }
    return false;
});

$('.reg').click(function () {
  $("#drop").toggleClass("animated fadeInUp").toggle();
})


 /* ---- Page Scrollup JS Start ---- */
 //When distance from top = 250px fade button in/out
  var scrollup = $('.scrollup');
  var headertag = $('header');
  var mainfix = $('.main');
  $(window).scroll(function(){
    if ($(this).scrollTop() > 0) {
        scrollup.fadeIn(300);
    } else {
        scrollup.fadeOut(300);
    }

    // /* header-fixed JS Start */
    // if ($(this).scrollTop() > 0){
    //    headertag.addClass("header-fixed");
    // }
    // else{
    //    headertag.removeClass("header-fixed");
    // }
    //
    // /* main-fixed JS Start */
    // if ($(this).scrollTop() > 0){
    //    mainfix.addClass("main-fixed");
    // }
    // else{
    //    mainfix.removeClass("main-fixed");
    // }
    /* ---- Page Scrollup JS End ---- */
  });


  //On click scroll to top of page t = 1000ms
  scrollup.on("click", function(){
      $("html, body").animate({ scrollTop: 0 }, 1000);
      return false;
  });
  $(".signup").click(function () {
    $(".signup-form").fadeIn();
    $(".login-form").fadeOut()
  })
  $(".login").click(function () {
    $(".login-form").fadeIn();
    $(".signup-form").fadeOut()
  })
  $(".reg-close").click(function () {
    $(".log-form,.over").addClass("animated ZoomOut").fadeOut()
  })
  $(".reg").click(function () {
    $(".log-form,.over").removeClass("animated ZoomOut")
    $(".log-form,.over").addClass("animated ZoomIn").fadeIn();
  })
$(document).ready(function() {
  // $("video").on("canplay",function () {
  //   console.log("loas");
  // })
  var wstick = $(window);
           wstick.on('scroll',function() {
              var scroll = wstick.scrollTop();
              if (scroll < 450) {
                $(".nav-container").removeClass("added")

              }else{
                $(".nav-container").addClass("added")
              }
           });

  $(".volunteer").click(function () {
    $(".v-form").removeClass("animated slideOutUp")
    $(".v-form").addClass("animated slideInDown").fadeIn();
    $("body,html").animate({scrollTop:0})
    $(".overlay").fadeIn('slow');

  })

  $(".close").click(function () {
    $(".v-form").removeClass("animated slideInDown").fadeOut();
    $(".custom-modal").removeClass("animated bounceIn").fadeOut();
    $(".custom-modal").addClass("animated bounceOut")
    $(".v-form").addClass("animated slideOutUp")
    $(".overlay").fadeOut('slow');
    $(".info-h-div").removeClass("animated ZoomOut").fadeOut();
    $(".artist-info").removeClass("animated bounceOut").fadeOut();




  })
  $('.news-l').click(function () {
    $(".info-h-div").removeClass("animated ZoomOut")
    $(".info-h-div").addClass("animated ZoomIn").fadeIn();
    $(".overlay").fadeIn('slow');
  })

  var maxlength=120;
  $('.card-text').each(function () {
    var mys=$(this).text();
    var id=$(this).attr("data_id")
      if($.trim(mys).length>maxlength){
       var news=mys.substring(0,maxlength);
       var removedstr=mys.substring(maxlength,$.trim(mys).length);
       $(this).empty().html(news+'...');
      }
});

 $(".show-tracks").click(function () {
   $(".custom-modal").removeClass("animated bounceOut");
   $(".overlay").fadeIn('slow');
   var id=$(this).data('id');
   $("#modal-"+id).addClass("animated bounceIn").fadeIn();
 })
$('.name-artist').click(function() {
    var id=$(this).data('id');
  $('.artist-info-'+id).addClass("animated bounce").fadeIn()
})

  $("#testimonial").owlCarousel({
    slideSpeed:300,
    paginationSpeed:400,
    singleItem:!0
  })
  /*----------------------
      brands-carousel
  ------------------------*/
  $(".brands-carousel").owlCarousel({
  autoPlay: false,
  slideSpeed:200,
  items : 5,
  pagination:false,
  navigation:true,
  navigationText:["<i class='ti ti-angle-left'></i>","<i class='ti ti-angle-right'></i>"],
  itemsDesktop : [1199,5],
  itemsDesktopSmall : [980,3],
  itemsTablet : [767,2],
  itemsMobile : [479,2]
  });
  $('.dropify').dropify();

$(".mobile-sub-menu").slideUp()
    // pretty prettyPhoto
  $(".lightbox-image").append("<span></span>");
  $(".lightbox-image span").css({opacity:1});

  $("#initial").validate({
    highlight: function(element) {
      $(element).closest('.form-g').removeClass('has-success').addClass('has-error')
      $(element).closest('.form-g').removeClass('has-success').addClass('has-error');
    },
    unhighlight: function(element) {
      $(element).closest('.form-g').removeClass('has-error').addClass('has-success');
    },
    messages:{
      fullname:{
        required:"Username field is required "
      },
      terms:{
        required:"Please agree With our terms and conditions "
      }
    },
    submitHandler:function(form, event) {
      var form=$(form).serializeArray()
       console.log(form);
    }
  });

      //**** countdown  ****//


    function countdown_clock() {
      $(".countdown-clock").downCount({
        date: $(".countdown-clock").attr("data-end-date"),
            offset: +10
        },
        function () {
          //alert('done!'); Finish Time limit
        return false;
      });
    }
    //****   Music aniamtion  ****//


    $(".m-banner span,.v-banner span,.s-banner span").fadeIn().animate({'padding-top':'200px'})
    $(".m-banner h4,.v-banner h4,.s-banner h4").fadeIn().animate({'padding-top':'150'})


    //**** countdown initaiation  ****//
    countdown_clock();


    //**** Audio player  ****//


  });



  //**** Home page Slider  ****//
  $(function () {
    $("#slider").responsiveSlides({
    auto: true,
    pager: false,
    nav: true,
    speed: 500,
    maxwidth: 960,
    namespace: "centered-btns"
    });
  });
